# GS-RepairJob - QBCore Civilian Repairman Job

A fully immersive, plug-and-play civilian job script for QBCore-based FiveM servers. Players can take on electrical/commercial repair jobs using a tablet system with leaderboards, vehicles, skill checks, payout tracking, and rank progression.

---

## 📦 Features

- 📍 Blip-based HQ location with NPC to go on/off duty
- 🛠️ Start random repair jobs with prop markers (including rooftop hints)
- 🎮 Skill check mini-game via ox_lib
- 📊 NUI Tablet with Dashboard, Leaderboard, Vehicle controls
- 🚐 Vehicle system (spawn/repair/return)
- 🧰 Required repair kits (with item check)
- 🧑‍🔧 Reputation-based ranks & payouts
- ⚡ Electrical repair shock risk if skill check fails
- 🧠 Memory-safe tab switching system
- 🔒 Anti-exploit cooldowns & checks
- 🔌 oxmysql + ox_lib + qb-target required

---

## 🧰 Dependencies

Ensure these resources are installed and running:
- [ox_lib](https://github.com/overextended/ox_lib)
- [oxmysql](https://github.com/overextended/oxmysql)
- [qb-core](https://github.com/qbcore-framework/qb-core)
- [qb-target](https://github.com/qbcore-framework/qb-target)

---

## 🚀 Installation

1. **Drop resource** into your `resources/` folder:
   ```
   resources/[local]/GS-RepairJob
   ```

2. **Ensure it in your server.cfg**:

3. **Import the SQL** into your database** (see `repairman.sql`):
   - Creates `repairman_stats` table for job tracking
   - Can be run via phpMyAdmin or any MySQL tool

4. **Add item to `qb-core/shared/items.lua`**:
```lua
["repairtablet"] = {
    ["name"] = "repairtablet",
    ["label"] = "Repair Tablet",
    ["weight"] = 100,
    ["type"] = "item",
    ["image"] = "repairtablet.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Used by field techs to manage jobs."
}
```

5. **Add item image**:
   - Place `repairtablet.png` into `qb-inventory/html/images/`

---

## 🧠 Config Options

Located in `config.lua`:
- `Config.HQ`: Job HQ location
- `Config.Vehicle`: Repair van spawn model
- `Config.Payouts`: Tier-based payout amounts
- `Config.Tiers`: Job count thresholds for ranks
- `Config.RepairKitItem`: Required item for repairs
- `Config.RepairPoints`: List of all repairable object locations

---

## 📊 SQL File Setup

See `repairman.sql`. It creates:

```sql
repairman_stats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    citizenid VARCHAR(50),
    jobs_completed INT DEFAULT 0,
    money_earned INT DEFAULT 0
)
```

---

## ⚠️ Notes & Tips

- If tablet UI opens but is blank, check if ox_lib & SQL table are properly installed
- Only players on duty can get jobs or spawn vehicles
- Leaderboard pulls top 5 based on job completions
- Vehicle spawns are limited by cooldown and proximity
- `repairtablet` is removed when going off duty

---

## 🧩 Future Ideas

- ⏱️ Job time tracking and bonuses
- 🧑‍🤝‍🧑 Co-op repair mode
- 🌐 Discord webhook integration
- 🔧 Admin panel for job configuration

---

Created by: **GooberScripts github.com/XyraL** 🙌
