local QBCore = exports['qb-core']:GetCoreObject()

CreateThread(function()
    local model = Config.HQTargetModel
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end

    local ped = CreatePed(0, model, Config.HQ.x, Config.HQ.y, Config.HQ.z - 1.0, 90.0, false, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                type = "client",
                icon = "fas fa-wrench",
                label = "Go On Duty",
                action = function() TriggerEvent("repairman:client:GoOnDuty") end
            },
            {
                type = "client",
                icon = "fas fa-sign-out-alt",
                label = "Go Off Duty",
                action = function() TriggerEvent("repairman:client:GoOffDuty") end
            },
            {
                type = "client",
                icon = "fas fa-toolbox",
                label = "Grab Repair Kit",
                action = function() TriggerEvent("repairman:client:GetRepairKit") end
            },
        },
        distance = 2.5,
    })

    local name = "Foreman Bob"
    CreateThread(function()
        while true do
            Wait(0)
            local coords = GetEntityCoords(ped)
            local dist = #(GetEntityCoords(PlayerPedId()) - coords)
            if dist <= 5.0 then
                DrawText3D(coords.x, coords.y, coords.z + 1.0, name)
            end
        end
    end)
end)

function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(x, y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end
