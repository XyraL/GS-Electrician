--Client/main.lua
local QBCore = exports['qb-core']:GetCoreObject()
local onDuty = false
local currentJob = nil
local jobBlip = nil
local lib = exports.ox_lib
local lastSpawnTime = 0
local currentVan = nil
local showRepairMarker = false
local jobStatus = "Inactive"
local bonusJob = nil

function UpdateTabletStatus()
    SendNUIMessage({
        action = "updateJobStatus",
        status = jobStatus
    })
end

CreateThread(function()
    local blip = AddBlipForCoord(Config.HQ)
    SetBlipSprite(blip, 446) -- Wrench icon
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 26)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Repairman HQ")
    EndTextCommandSetBlipName(blip)
end)

-- HQ NPC Spawn
CreateThread(function()
    local modelHash = joaat(Config.HQTargetModel or "s_m_m_lathandy_01")

    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do Wait(0) end

    local ped = CreatePed(0, modelHash, Config.HQ.x, Config.HQ.y, Config.HQ.z - 1.0, 180.0, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)

    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                icon = "fas fa-briefcase",
                label = "Go On Duty",
                action = function()
                    TriggerEvent("repairman:client:GoOnDuty")
                end
            },
            {
                icon = "fas fa-toolbox",
                label = "Get Repair Kit",
                action = function()
                    TriggerEvent("repairman:client:GetRepairKit")
                end
            },
            {
                icon = "fas fa-sign-out-alt",
                label = "Go Off Duty",
                action = function()
                    TriggerEvent("repairman:client:GoOffDuty")
                end
            },
        },
        distance = 2.5,
    })
end)

-- repair marker display
CreateThread(function()
    while true do
        Wait(0)
        if showRepairMarker and currentJob and currentJob.coords then
            local coords = currentJob.coords

            -- Glowing floating dot above repair location
            DrawMarker(2, coords.x, coords.y, coords.z + 2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                       0.5, 0.5, 0.5, 255, 185, 0, 200, false, false, 2, true, nil, nil, false)

            -- Notify once if job is elevated
if not currentJob.roofHintShown then
    local playerZ = GetEntityCoords(PlayerPedId()).z
    if coords.z - playerZ > 3.0 then
        QBCore.Functions.Notify("🔺 This repair is located above you — check rooftops or ladders!", "primary")
        currentJob.roofHintShown = true
    end
end
        end
    end
end)

-- 🔧 Main repair function
function DoRepairJob(job)
    if not onDuty then
        QBCore.Functions.Notify("You must be on duty to do this!", "error")
        return
    end

    jobStatus = "🛠️ In Progress"
    UpdateTabletStatus()

    -- Check for repair kit
    local PlayerData = QBCore.Functions.GetPlayerData()
    local hasKit = false

    for _, item in pairs(PlayerData.items) do
        if item.name == Config.RepairKitItem and item.amount >= 1 then
            hasKit = true
            break
        end
    end

    if not hasKit then
        QBCore.Functions.Notify("You need a Repair Kit to do this job.", "error")
        return
    end

    -- Set animation and skill check based on job type
    local anim = "WORLD_HUMAN_WELDING"
    local skill = {'easy', 'medium'}

    if job.type == "hvac" then
        anim = "PROP_HUMAN_BUM_BIN"
        skill = {'medium'}
    elseif job.type == "plumbing" then
        anim = "WORLD_HUMAN_CONST_DRILL"
        skill = {'easy'}
    end

    -- Skill check
    local passed = lib:skillCheck(skill, {'w', 'a', 's', 'd'})

    if not passed then
        QBCore.Functions.Notify("Repair failed. Try again.", "error")
        TriggerServerEvent("repairman:server:JobFailed")

        -- Optional shock logic for electrical
        if Config.EnableShockSystem and job.type == "electrical" then
            local shockRoll = math.random(1, 100)
            if shockRoll <= Config.ShockChance then
                QBCore.Functions.Notify("⚡ You were shocked by the panel!", "error")
                SetPedToRagdoll(PlayerPedId(), 1000, 1500, 0, false, false, false)
                ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 0.25)
                TriggerServerEvent("repairman:server:RecordShock")
            end
        end
        return
    end

    -- Begin animation and repair progress
    local ped = PlayerPedId()
    TaskStartScenarioInPlace(ped, anim, 0, true)

    QBCore.Functions.Progressbar("repairing", "Repairing appliance...", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function()
        ClearPedTasks(ped)

        -- Reward
        TriggerServerEvent("repairman:server:FinishJob", job.payout)
        TriggerServerEvent("repairman:server:RefreshProfile")
        jobStatus = "✅ Completed"
        UpdateTabletStatus()

        -- Cleanup
        if jobBlip then
            RemoveBlip(jobBlip)
            jobBlip = nil
        end

        currentJob = nil
        exports['qb-target']:RemoveZone("repairjob")
        QBCore.Functions.Notify("Repair complete!", "success")
    end)
end

function HasRepairKit()
    local PlayerData = QBCore.Functions.GetPlayerData()
    for _, item in pairs(PlayerData.items) do
        if item.name == Config.RepairKitItem and item.amount >= 1 then
            return true
        end
    end
    return false
end

RegisterNetEvent("repairman:client:BeginJob", function()
    if currentJob then
        QBCore.Functions.Notify("You already have an active job!", "error")
        return
    end
    if not onDuty then
    QBCore.Functions.Notify("You must be on duty to do this!", "error")
    return
end

    jobStatus = "🟢 Active"
    UpdateTabletStatus()

-- 3D label above repair box
CreateThread(function()
    local showing = true
    while showing do
        Wait(0)
        if currentJob then
            local dist = #(GetEntityCoords(PlayerPedId()) - currentJob.coords)
        else
            showing = false
        end
    end
end)

    local job = Config.RepairPoints[math.random(1, #Config.RepairPoints)]
    currentJob = job

    --  Dispatch Message
    local street = GetStreetNameAtCoord(job.coords.x, job.coords.y, job.coords.z)
    local location = GetStreetNameFromHashKey(street)
    QBCore.Functions.Notify("📡 Repair request received near " .. location, "primary", 7500)

    --  Blip
    jobBlip = AddBlipForCoord(job.coords)
    SetBlipSprite(jobBlip, 446)
    SetBlipScale(jobBlip, 0.9)
    SetBlipColour(jobBlip, 26)
    SetBlipRoute(jobBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Repair Job: " .. job.label)
    EndTextCommandSetBlipName(jobBlip)

    --  Target Zone
    exports['qb-target']:AddBoxZone("repairjob", job.coords, 1.5, 1.5, {
    name = "repairjob",
    heading = 0,
    debugPoly = false,
    minZ = job.coords.z - 1.0,
    maxZ = job.coords.z + 1.0
}, {
    options = {
        {
            type = "client", 
            icon = "fas fa-tools",
            label = "Start Repair",
            action = function()
                if currentJob then
                    DoRepairJob(currentJob)
                else
                    QBCore.Functions.Notify("No job assigned.", "error")
                end
            end
        }
    },
    distance = 2.0
})

end)

RegisterNetEvent("repairman:client:GoOnDuty", function()
    TriggerEvent("repairman:client:GoOnDutyLogic")
    SendNUIMessage({
    action = "updateDutyStatus",
    onDuty = true
})
end)

RegisterNetEvent("repairman:client:GoOnDutyLogic", function()
    local Player = QBCore.Functions.GetPlayerData()
    if onDuty then QBCore.Functions.Notify("You're already on duty.", "error") return end

    TriggerServerEvent("repairman:server:SetJob", true)

    local ped = PlayerPedId()
    local gender = Player.charinfo.gender == 0 and "male" or "female"
    local uniform = Config.Uniforms[gender]

    for k, v in pairs(uniform) do
        SetPedComponentVariation(ped, tonumber(string.match(k, "%d+")), v, 0, 2)
    end

    TriggerServerEvent("repairman:server:GiveTablet")
    onDuty = true
    QBCore.Functions.Notify("You're now on duty!", "success")
    QBCore.Functions.Notify("Go into the parking lot to spawn vehicle!")
    QBCore.Functions.Notify("This is done through your tablet!")

    SendNUIMessage({
    action = "updateDutyStatus",
    onDuty = true
})

end)

RegisterNetEvent("repairman:client:UseTablet", function()
    SetNuiFocus(true, true)

    local Player = QBCore.Functions.GetPlayerData()
    local fullName = Player.charinfo.firstname .. " " .. Player.charinfo.lastname

    QBCore.Functions.TriggerCallback("repairman:server:GetStats", function(stats)
        local jobs = stats.jobs_completed or 0
        local tierLabel = "Rookie"

        if jobs >= 50 then
            tierLabel = Config.Tiers[4].label
        elseif jobs >= 25 then
            tierLabel = Config.Tiers[3].label
        elseif jobs >= 10 then
            tierLabel = Config.Tiers[2].label
        else
            tierLabel = Config.Tiers[1].label
        end

        TriggerServerEvent("repairman:server:RefreshProfile")
        SendNUIMessage({
            type = "openTablet",
            profile = {
                name = fullName,
                jobsCompleted = stats.jobs_completed or 0,
                jobsAttempted = stats.jobs_attempted or 0,
                moneyEarned = stats.money_earned or 0,
                rank = tierLabel
            },
            onDuty = onDuty
        })
    end)
end)

RegisterNetEvent("repairman:client:GoOffDuty", function()
    if not onDuty then
        QBCore.Functions.Notify("You're not on duty.", "error")
        return
    end

    -- 🔴 Cancel active job
    if currentJob then
        QBCore.Functions.Notify("Your current job has been cancelled.", "error")
        
        if jobBlip then
            RemoveBlip(jobBlip)
            jobBlip = nil
        end

        exports['qb-target']:RemoveZone("repairjob")
        currentJob = nil
        jobStatus = "Inactive"
        UpdateTabletStatus()
    end

    TriggerServerEvent("repairman:server:SetJob", false)

    onDuty = false
    QBCore.Functions.Notify("You are now off duty.", "primary")

    -- ✅ Notify UI
    SendNUIMessage({
        action = "updateDutyStatus",
        onDuty = false
    })
end)

RegisterNetEvent("repairman:client:GetRepairKit", function()
    if not onDuty then
    QBCore.Functions.Notify("You must be on duty to do this!", "error")
    return
end
    TriggerServerEvent("repairman:server:GiveRepairKit")
end)

RegisterNetEvent("repairman:client:SpawnVehicle", function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local dist = #(pos - Config.VehicleSpawn.xyz)

    if not onDuty then
    QBCore.Functions.Notify("You must be on duty to do this!", "error")
    return
end

    if dist > 50.0 then
        QBCore.Functions.Notify("You must be near HQ to spawn your work vehicle.", "error")
        return
    end

    local timeNow = GetGameTimer()
    if timeNow - lastSpawnTime < 60000 then
        QBCore.Functions.Notify("You can only spawn a vehicle once every 60 seconds.", "error")
        return
    end
    lastSpawnTime = timeNow

    QBCore.Functions.SpawnVehicle(Config.Vehicle, function(veh)
        currentVan = veh
        TaskWarpPedIntoVehicle(ped, veh, -1)
        SetVehicleNumberPlateText(veh, "REPAIR"..math.random(100,999))
        TriggerEvent("vehiclekeys:client:SetOwner", GetVehicleNumberPlateText(veh))
    end, Config.VehicleSpawn, true)
end)

RegisterNetEvent("repairman:client:ReturnVehicle", function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local dist = #(pos - Config.VehicleSpawn.xyz)

    if not onDuty then
    QBCore.Functions.Notify("You must be on duty to do this!", "error")
    return
end

    if dist > 50.0 then
        QBCore.Functions.Notify("You must be near HQ to return your van.", "error")
        return
    end

    if currentVan and DoesEntityExist(currentVan) then
        DeleteEntity(currentVan)
        currentVan = nil
        QBCore.Functions.Notify("Vehicle returned successfully.", "success")
    else
        QBCore.Functions.Notify("No repair van to return.", "error")
    end
end)

RegisterNetEvent("repairman:client:RepairVan", function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local dist = #(pos - Config.VehicleSpawn.xyz)

    if not onDuty then
    QBCore.Functions.Notify("You must be on duty to do this!", "error")
    return
end

    if dist > 50.0 then
        QBCore.Functions.Notify("You must be near HQ to repair your van.", "error")
        return
    end

    local veh = GetVehiclePedIsIn(ped, false)

    if veh == 0 then
        QBCore.Functions.Notify("You're not in a vehicle.", "error")
        return
    end

    if veh ~= currentVan then
        QBCore.Functions.Notify("You can only repair your work van.", "error")
        return
    end

    SetVehicleFixed(veh)
    SetVehicleDirtLevel(veh, 0.0)
    QBCore.Functions.Notify("Repair van fully serviced!", "success")
end)

RegisterNetEvent("repairman:client:UpdateProfile", function(data)
    SendNUIMessage({
        action = "updateProfile",
        profile = {
            name = data.name,
            jobsCompleted = data.jobsCompleted,
            moneyEarned = data.moneyEarned,
            rank = "Tier " .. data.rank,
            jobsAttempted = data.jobsAttempted
        }
    })

    SendNUIMessage({
        action = "updateAnalytics",
        data = {
            jobsAttempted = data.jobsAttempted,
            successRate = data.successRate,
            avgTime = data.avgTime,
            shocksTaken = data.shocksTaken
        }
    })
end)

RegisterNUICallback("startJob", function(_, cb)
    TriggerEvent("repairman:client:BeginJob")
    cb("ok")
end)

RegisterNUICallback("spawnVehicle", function(_, cb)
    TriggerEvent("repairman:client:SpawnVehicle")
    cb("ok")
end)

RegisterNUICallback("coopInvite", function(_, cb)
    -- Placeholder for co-op
    QBCore.Functions.Notify("Co-op invite system coming soon!")
    cb("ok")
end)

RegisterNUICallback("endShift", function(_, cb)
    SetNuiFocus(false, false) 
    SendNUIMessage({ type = "closeTablet" })
    TriggerEvent("repairman:client:GoOffDuty")
    cb("ok")
end)

RegisterNUICallback("closeTablet", function(_, cb)
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterNUICallback("returnVehicle", function(_, cb)
    TriggerEvent("repairman:client:ReturnVehicle")
    cb("ok")
end)

RegisterNUICallback("repairVan", function(_, cb)
    TriggerEvent("repairman:client:RepairVan")
    cb("ok")
end)

RegisterNUICallback("toggleRepairMarker", function(_, cb)
    showRepairMarker = not showRepairMarker
    cb("ok")
end)

RegisterNUICallback("getLeaderboard", function(_, cb)
    QBCore.Functions.TriggerCallback("repairman:server:GetLeaderboard", function(data)
        cb(data)
    end)
end)

RegisterNUICallback("getBonusJob", function(_, cb)
    QBCore.Functions.TriggerCallback("repairman:server:GetBonusJob", function(job)
        if job then
            bonusJob = job
            cb({ hasBonus = true, label = job.label })
        else
            cb({ hasBonus = false })
        end
    end)
end)

RegisterNUICallback("acceptBonusJob", function(_, cb)
    TriggerServerEvent("repairman:server:AcceptBonusJob")
    cb("ok")
end)

RegisterNUICallback("goOnDuty", function(_, cb)
    TriggerEvent("repairman:client:GoOnDutyLogic")
    cb("ok")
end)

RegisterNUICallback("goOffDuty", function(_, cb)
    TriggerEvent("repairman:client:GoOffDuty")
    cb("ok")
end)

RegisterNetEvent("repairman:client:StartBonusJob", function(job)
    QBCore.Functions.Notify("🚨 Emergency job accepted!", "primary")
    TriggerEvent("repairman:client:BeginJob", job, true)
end)

RegisterNetEvent("repairman:client:SetBonusJob", function(job)
    bonusJob = job
    SendNUIMessage({ type = "showBonusJob", label = job.label })
end)
