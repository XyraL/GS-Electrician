Config = {}

-- Job Info
Config.JobName = "repairman"
Config.UseJobSystem = true -- Player gets 'repairman' job when on duty

-- HQ Location (Main Office)
Config.HQ = vector3(1165.54, -1347.2, 35.96) -- <-- Can change to your own HQ (This is the ped)
Config.HQTargetModel = "s_m_m_lathandy_01" -- Repairman ped <--- Can change to your own ped of liking

-- Vehicle
Config.Vehicle = "burrito" -- <-- Any vehicle spawn code name
Config.VehicleSpawn = vector4(1130.37, -1301.38, 34.55, 358.81) -- <--- Where vehicle spawns (Can change)

-- Uniforms
Config.Uniforms = {
    male = {
        tshirt_1 = 59, tshirt_2 = 1,
        torso_1 = 38, torso_2 = 3,
        pants_1 = 36, pants_2 = 1,
        shoes_1 = 12, shoes_2 = 6,
    },
    female = {
        tshirt_1 = 36, tshirt_2 = 1,
        torso_1 = 38, torso_2 = 3,
        pants_1 = 34, pants_2 = 1,
        shoes_1 = 27, shoes_2 = 0,
    }
}

-- Repair Kit System
Config.RepairKitItem = "repairkit" -- <---- item may be changed to your own custom item. 
Config.RequiredKitsPerJob = 1

-- Repair Locations (more can be added)
Config.RepairPoints = {
    {
        label = "Junction Box",
        coords = vector3(360.3, -1034.58, 28.31),
        prop = "prop_elecbox_16",
        type = "electrical",
        payout = 300
    },
    {
        label = "High Voltage Box",
        coords = vector3(-383.01, -368.84, 31.67),
        prop = "prop_elecbox_16",
        type = "electrical",
        payout = 300
    },
    {
        label = "High Voltage Panel",
        coords = vector3(171.02, -765.66, 32.18),
        prop = "prop_elecbox_16",
        type = "electrical",
        payout = 300
    },
    {
        label = "Electrical Box",
        coords = vector3(1157.45, -1462.47, 34.86),
        prop = "prop_elecbox_16",
        type = "electrical",
        payout = 300
    },
    {
        label = "Roof AC Box",
        coords = vector3(-1130.7, -1601.3, 7.62),
        prop = "prop_elecbox_16",
        type = "hvac",
        payout = 300
    },
    {
        label = "Roof AC Unit",
        coords = vector3(-1343.09, -1130.89, 21.96),
        prop = "prop_elecbox_16",
        type = "hvac",
        payout = 300
    },
    {
        label = "Traffic Signal Panel",
        coords = vector3(-56.02, -1621.81, 29.42),
        prop = "prop_traffic_lightbox",
        type = "electrical",
        payout = 250
    }
}

-- Skillcheck Difficulty
Config.SkillCheck = {
    difficulty = { "easy", "medium" },
    failChance = 20
}

-- Shock System
Config.EnableShockSystem = true
Config.ShockChance = 40 -- % chance to be shocked when failing electrical jobs

-- Bonus Jobs
Config.EnableBonusJobs = true
Config.BonusJobInterval = 10 -- Minutes
Config.BonusJobMultiplier = 1.5 -- Payout multiplier
Config.BonusJobBlipColor = 47 -- Orange

Config.Tiers = {
    [1] = {label = "Rookie", payoutMultiplier = 1.0},
    [2] = {label = "Junior Tech", payoutMultiplier = 1.2},
    [3] = {label = "Field Engineer", payoutMultiplier = 1.5},
    [4] = {label = "Master Repairman", payoutMultiplier = 2.0},
}