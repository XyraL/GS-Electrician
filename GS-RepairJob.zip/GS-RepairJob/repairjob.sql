-- repairman.sql
-- Table used for GS-RepairJob script

CREATE TABLE IF NOT EXISTS `repairman_stats` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `jobs_completed` INT NOT NULL DEFAULT 0,
    `money_earned` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `citizenid_UNIQUE` (`citizenid`)
);
