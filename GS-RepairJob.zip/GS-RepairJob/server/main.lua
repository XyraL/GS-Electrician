-- server/main.lua
local QBCore = exports['qb-core']:GetCoreObject()
local lib = exports.ox_lib
local bonusJob = nil

QBCore.Functions.CreateUseableItem("repairtablet", function(source)
    TriggerClientEvent("repairman:client:UseTablet", source)
end)


RegisterServerEvent("repairman:server:SetJob", function(status)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    if status then
        Player.Functions.SetJob(Config.JobName, 0) 
    else
        Player.Functions.SetJob("unemployed", 0)
    end
end)


RegisterServerEvent("repairman:server:GiveTablet", function()
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        local hasTablet = Player.Functions.GetItemByName("repairtablet")
        if not hasTablet then
            Player.Functions.AddItem("repairtablet", 1)
            TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items["repairtablet"], "add")
        end
    end
end)


RegisterServerEvent("repairman:server:RemoveTablet", function()
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        Player.Functions.RemoveItem("repairtablet", 1)
        TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items["repairtablet"], "remove")
    end
end)

RegisterServerEvent("repairman:server:GiveRepairKit", function()
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        Player.Functions.AddItem(Config.RepairKitItem, 1)
        TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items[Config.RepairKitItem], "add")
    end
end)

RegisterServerEvent("repairman:server:FinishJob", function(payout)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid

    -- Remove item
    Player.Functions.RemoveItem(Config.RepairKitItem, Config.RequiredKitsPerJob)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[Config.RepairKitItem], "remove")

    -- Add money
    Player.Functions.AddMoney("bank", payout, "repair-job-payout")

    -- ✅ Count as success and attempt
MySQL.execute([[
    INSERT INTO repairman_stats (citizenid, jobs_completed, money_earned, jobs_attempted)
    VALUES (?, 1, ?, 1)
    ON DUPLICATE KEY UPDATE 
        jobs_completed = jobs_completed + 1,
        money_earned = money_earned + ?,
        jobs_attempted = jobs_attempted + 1
]], { citizenid, payout, payout })

    -- ✅ Now fetch the updated stats
    local stats = MySQL.query.await("SELECT * FROM repairman_stats WHERE citizenid = ?", {citizenid})
    stats = stats[1]

    if stats then
        local attempts = stats.jobs_attempted or 0
        local completed = stats.jobs_completed or 0
        local shocks = stats.shocks_taken or 0
        local avgTime = stats.total_repair_time and math.floor(stats.total_repair_time / math.max(1, completed)) or 0

        TriggerClientEvent("repairman:client:UpdateProfile", src, {
            name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
            jobsCompleted = completed,
            jobsAttempted = attempts,
            moneyEarned = stats.money_earned,
            rank = stats.tier,
            successRate = attempts > 0 and math.floor((completed / attempts) * 100) or 0,
            avgTime = avgTime,
            shocksTaken = shocks
        })
    end
end)

RegisterNetEvent("repairman:server:RefreshProfile", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local cid = Player.PlayerData.citizenid

    MySQL.query('SELECT * FROM repairman_stats WHERE citizenid = ?', {cid}, function(result)
        local stats = result[1] or {
            jobs_completed = 0,
            money_earned = 0,
            jobs_attempted = 0,
            shocks_taken = 0,
            avg_time = 0
        }

        local jobs = stats.jobs_completed or 0
        local tier = 1
        if jobs >= 50 then tier = 4
        elseif jobs >= 25 then tier = 3
        elseif jobs >= 10 then tier = 2 end

        -- Avoid divide by 0
        local attempts = stats.jobs_attempted or 0
        local completed = stats.jobs_completed or 0
        local successRate = (attempts > 0) and math.floor((completed / attempts) * 100) or 0

        TriggerClientEvent("repairman:client:UpdateProfile", src, {
            name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
            jobsCompleted = completed,
            moneyEarned = stats.money_earned or 0,
            rank = tier,
            jobsAttempted = attempts,
            successRate = successRate,
            avgTime = (stats.jobs_attempted > 0) and math.floor(stats.total_repair_time / stats.jobs_attempted) or 0,
            shocksTaken = stats.shocks_taken or 0
        })
    end)
end)

RegisterNetEvent("repairman:server:RecordShock", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local cid = Player.PlayerData.citizenid

    MySQL.update('UPDATE repairman_stats SET shocks_taken = shocks_taken + 1 WHERE citizenid = ?', {cid})
end)

CreateThread(function()
    while true do
        Wait(Config.BonusJobInterval * 60000)

        if Config.EnableBonusJobs then
            local random = math.random(1, #Config.RepairPoints)
            bonusJob = Config.RepairPoints[random]
            TriggerClientEvent("repairman:client:SetBonusJob", -1, bonusJob)
        end
    end
end)

QBCore.Functions.CreateCallback("repairman:server:GetBonusJob", function(_, cb)
    cb(bonusJob)
end)

RegisterNetEvent("repairman:server:AcceptBonusJob", function()
    local src = source
    TriggerClientEvent("repairman:client:StartBonusJob", src, bonusJob)
    MySQL.update('UPDATE repairman_stats SET jobs_attempted = jobs_attempted + 1 WHERE citizenid = ?', {citizenid})
    bonusJob = nil
end)

RegisterNetEvent("repairman:server:JobFailed", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid
    MySQL.execute([[
        INSERT INTO repairman_stats (citizenid, jobs_attempted)
        VALUES (?, 1)
        ON DUPLICATE KEY UPDATE jobs_attempted = jobs_attempted + 1
    ]], {citizenid})
end)


QBCore.Functions.CreateCallback("repairman:server:GetStats", function(src, cb)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return cb(nil) end

    MySQL.query('SELECT jobs_completed, money_earned FROM repairman_stats WHERE citizenid = ?', {
        Player.PlayerData.citizenid
    }, function(result)
        if result and result[1] then
            cb({
                jobsCompleted = result[1].jobs_completed,
                moneyEarned = result[1].money_earned
            })
        else
            cb({ jobsCompleted = 0, moneyEarned = 0 })
        end
    end)
end)

QBCore.Functions.CreateCallback("repairman:server:GetLeaderboard", function(source, cb)
    exports.oxmysql:execute([[
        SELECT
            JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')) AS firstname,
            JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')) AS lastname,
            r.jobs_completed,
            r.money_earned
        FROM players p
        JOIN repairman_stats r ON p.citizenid = r.citizenid
        ORDER BY r.jobs_completed DESC
        LIMIT 5
    ]], {}, function(results)
        cb(results or {})
    end)
end)