window.addEventListener("message", function (event) {
    const data = event.data;

    if (data.type === "openTablet") {
        document.body.style.display = "block";
        updateProfile(data.profile);
        updateAnalytics(data.analytics);
        updateClockStatus(data.onDuty);
        openTab("dashboard");
    }

    if (data.type === "closeTablet") {
        document.body.style.display = "none";
    }

    if (data.action === "updateJobStatus") {
        const timeClockStatusLabel = document.getElementById("timeClockStatusLabel");
        const dashboardStatusLabel = document.getElementById("jobStatusLabel");
        if (timeClockStatusLabel) timeClockStatusLabel.textContent = `Status: ${data.status}`;
        if (dashboardStatusLabel) dashboardStatusLabel.textContent = `Status: ${data.status}`;
    }

    if (data.action === "showLeaderboard") {
        const list = document.getElementById("leaderboardList");
        if (list) {
            list.innerHTML = "";
            if (!Array.isArray(data.data)) {
                console.error("Leaderboard data is not an array:", data.data);
                return;
            }
            data.data.forEach((entry, index) => {
                const item = document.createElement("li");
                item.textContent = `${index + 1}. ${entry.firstname} ${entry.lastname} - ${entry.jobs_completed} jobs - $${entry.money_earned}`;
                list.appendChild(item);
            });
        }
    }

    if (data.action === "updateProfile" && data.profile) {
        updateProfile(data.profile);
    }

    if (data.action === "updateAnalytics" && data.data) {
        updateAnalytics(data.data);
    }

    if (data.action === "toggleDutyButtons") {
        const onBtn = document.getElementById("goOnDutyBtn");
        const offBtn = document.getElementById("goOffDutyBtn");
        if (onBtn && offBtn) {
            if (data.onDuty) {
                onBtn.style.display = "none";
                offBtn.style.display = "inline-block";
            } else {
                onBtn.style.display = "inline-block";
                offBtn.style.display = "none";
            }
        }
    }

    if (data.action === "updateDutyStatus") {
        updateClockStatus(data.onDuty);
    }
});

function updateProfile(profile) {
    document.getElementById("playerName").textContent = profile.name;
    document.getElementById("jobsCompleted").textContent = profile.jobsCompleted;
    document.getElementById("moneyEarned").textContent = profile.moneyEarned;
    document.getElementById("playerRank").textContent = profile.rank;
    document.getElementById("jobsAttempted").textContent = profile.jobsAttempted;

    const rate = profile.jobsAttempted > 0 ? Math.floor((profile.jobsCompleted / profile.jobsAttempted) * 100) : 0;
    document.getElementById("successRate").textContent = `${rate}%`;
}

function updateAnalytics(data) {
    const attempted = document.getElementById("jobsAttempted");
    const rate = document.getElementById("successRate");
    const time = document.getElementById("avgRepairTime");
    const shocks = document.getElementById("shocksTaken");

    const attempts = data?.jobsAttempted ?? 0;
    const completed = data?.jobsCompleted ?? 0;

    if (attempted) attempted.textContent = attempts;
    if (rate) rate.textContent = `${data?.successRate ?? 0}%`;
    if (time) time.textContent = `${data?.avgTime ?? 0}s`;
    if (shocks) shocks.textContent = data?.shocksTaken ?? 0;
}


function updateClockStatus(onDuty) {
    const status = document.getElementById("clockStatus");
    const onBtn = document.getElementById("goOnDutyBtn");
    const offBtn = document.getElementById("goOffDutyBtn");

    if (onDuty) {
        if (status) status.textContent = "On Duty";
        if (onBtn) onBtn.style.display = "none";
        if (offBtn) offBtn.style.display = "inline-block";
    } else {
        if (status) status.textContent = "Off Duty";
        if (onBtn) onBtn.style.display = "inline-block";
        if (offBtn) offBtn.style.display = "none";
    }
}

function openTab(tabId) {
    const tabs = document.querySelectorAll(".tabcontent");
    tabs.forEach(tab => tab.style.display = "none");

    const selectedTab = document.getElementById(tabId);
    if (selectedTab) selectedTab.style.display = "block";

    if (tabId === "leaderboard") {
        fetch(`https://${GetParentResourceName()}/getLeaderboard`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({})
        })
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("leaderboardList");
            list.innerHTML = "";

            if (Array.isArray(data) && data.length > 0) {
                data.forEach((entry, index) => {
                    const item = document.createElement("li");
                    item.textContent = `${index + 1}. ${entry.firstname} ${entry.lastname} - ${entry.jobs_completed} jobs - $${entry.money_earned}`;
                    list.appendChild(item);
                });
            } else {
                const item = document.createElement("li");
                item.textContent = "No data found.";
                list.appendChild(item);
            }
        })
        .catch(err => {
            console.error("Leaderboard fetch error", err);
        });
    }

    if (tabId === "startjob") {
        loadBonusJob();
    }
}

function loadBonusJob() {
    fetch(`https://${GetParentResourceName()}/getBonusJob`, {
        method: "POST"
    })
    .then(res => res.json())
    .then(data => {
        const container = document.getElementById("bonusJobContainer");
        const label = document.getElementById("bonusJobLabel");

        if (data.hasBonus && container && label) {
            container.style.display = "block";
            label.textContent = `🚨 Bonus Job: ${data.label}`;
        } else if (container) {
            container.style.display = "none";
        }
    })
    .catch(err => console.error("Bonus Job Load Error:", err));
}

// Job-related NUI triggers
function startJob() {
    fetch(`https://${GetParentResourceName()}/startJob`, { method: "POST" });
}
function spawnVehicle() {
    fetch(`https://${GetParentResourceName()}/spawnVehicle`, { method: "POST" });
}
function sendCoopInvite() {
    fetch(`https://${GetParentResourceName()}/coopInvite`, { method: "POST" });
}
function endShift() {
    fetch(`https://${GetParentResourceName()}/endShift`, { method: "POST" });
}
function returnVehicle() {
    fetch(`https://${GetParentResourceName()}/returnVehicle`, { method: "POST" });
}
function repairVan() {
    fetch(`https://${GetParentResourceName()}/repairVan`, { method: "POST" });
}
function acceptBonusJob() {
    fetch(`https://${GetParentResourceName()}/acceptBonusJob`, { method: "POST" });
}
function goOnDuty() {
    fetch(`https://${GetParentResourceName()}/goOnDuty`, { method: "POST" });
}
function goOffDuty() {
    fetch(`https://${GetParentResourceName()}/goOffDuty`, { method: "POST" });
}

// Toggle repair marker
const repairMarkerBtn = document.getElementById("toggleRepairMarkerBtn");
if (repairMarkerBtn) {
    repairMarkerBtn.addEventListener("click", () => {
        fetch(`https://${GetParentResourceName()}/toggleRepairMarker`, {
            method: "POST"
        });
    });
}

// ESC key closes tablet
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
        document.body.style.display = "none";
        fetch(`https://${GetParentResourceName()}/closeTablet`, {
            method: "POST"
        });
    }
});
